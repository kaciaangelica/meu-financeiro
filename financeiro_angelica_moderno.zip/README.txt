MEU FINANCEIRO — ANGÉLICA

Publique esta pasta em um serviço de hospedagem estática. O arquivo inicial é index.html.
Os dados são armazenados localmente no navegador; use Exportar backup regularmente.
